package modelo;

public class VendaProduto {
	private int vendaId;
	private int produtoId;
	private int quantidade;
	private double preco;
	
	public VendaProduto() {}
	
	public VendaProduto(int vendaId, int produtoId, int quantidade, double preco) {
		this.vendaId = vendaId;
		this.produtoId = produtoId;
		this.quantidade = quantidade;
		this.preco = preco;
	}

	public int getVendaId() {
		return vendaId;
	}

	public void setVendaId(int vendaId) {
		this.vendaId = vendaId;
	}

	public int getProdutoId() {
		return produtoId;
	}

	public void setProdutoId(int produtoId) {
		this.produtoId = produtoId;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	@Override
	public String toString() {
		return "VendaProduto [vendaId=" + vendaId + ", produtoId=" + produtoId + ", quantidade=" + quantidade
				+ ", preco=" + preco + "]";
	}
}
