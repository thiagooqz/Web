package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import conexao.Conexao;
import modelo.Usuario;
import modelo.Venda;
import modelo.VendaProduto;

public class UsuarioDAO {
	
	public List<Usuario> obterTodosUsuarios(){
		List<Usuario> usuarios = new ArrayList<>();
		String sql = "SELECT * FROM Usuario";
		
		try {
			Connection conn = Conexao.getConexao();
			
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				String cpf = rs.getString("cpf");
				String telefone = rs.getString("telefone");
				String endereco = rs.getString("endereco");
				String email = rs.getString("email");
				String login = rs.getString("login");
				String senha = rs.getString("senha");
				
				usuarios.add(new Usuario(id, nome, cpf, telefone, endereco, email, login, senha));		
			}
			
			return usuarios;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
				
	}
	
	public Usuario obterUsuarioId(int id) {
        Usuario usuario = null;
        String sql = "SELECT * FROM Usuario WHERE id = ?";

        try {
        	Connection conn = Conexao.getConexao();
 
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                String nome = rs.getString("nome");
                String cpf = rs.getString("cpf");
                String telefone = rs.getString("telefone");
                String endereco = rs.getString("endereco");
                String email = rs.getString("email");
                String login = rs.getString("login");
                String senha = rs.getString("senha");
                
                usuario = new Usuario(id, nome, cpf, telefone, endereco, email, login, senha);
            }
            
            return usuario;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
	
	public boolean cadastrarUsuario(Usuario usuario) {
		String sql = "INSERT INTO Usuario (nome, cpf, telefone, endereco, email, login, senha) VALUES (?, ?, ?, ?, ?, ?, ?)";
		
		try {
			Connection conn = Conexao.getConexao();

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, usuario.getNome());
			pstmt.setString(2, usuario.getCpf());
			pstmt.setString(3, usuario.getTelefone());
			pstmt.setString(4, usuario.getEndereco());
			pstmt.setString(5, usuario.getEmail());
			pstmt.setString(6, usuario.getLogin());
			pstmt.setString(7, usuario.getSenha());
			
			int tuplasInseridas = pstmt.executeUpdate();
			
			if(tuplasInseridas > 0) {
				return true;
			} else {
				return false;
			}
				
		} catch (SQLException e) {
				e.printStackTrace();
				return false;
		}
	}
	
	public boolean atualizarUsuario(Usuario usuario) {
		String sql = "UPDATE Usuario SET nome = ?, cpf = ?, telefone = ?, endereco = ?, email = ?, login = ?, senha = ? WHERE ID = ?";
		
		try {
			Connection conn = Conexao.getConexao();
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, usuario.getNome());
			pstmt.setString(2, usuario.getCpf());
			pstmt.setString(3, usuario.getTelefone());
			pstmt.setString(4, usuario.getEndereco());				
			pstmt.setString(5, usuario.getEmail());
			pstmt.setString(6, usuario.getLogin());
			pstmt.setString(7, usuario.getSenha());
			pstmt.setInt(8, usuario.getId());
			
			int tuplasModificadas = pstmt.executeUpdate();
			
			if(tuplasModificadas > 0) {
				return true;
			} else {
				return false;
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean removerUsuario(int id) {
		String sql = "DELETE FROM Usuario WHERE id = ?";
		
		try {
			Connection conn = Conexao.getConexao();

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			int tuplasRemovidas = pstmt.executeUpdate();
			
			if(tuplasRemovidas > 0) {
				return true;
			} else {
				return false;
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean autenticarUsuario(String login, String senha) {
		String sql = "SELECT * FROM Usuario WHERE login = ? AND senha = ?";
		
		try {
			Connection conn = Conexao.getConexao();
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, login);
			pstmt.setString(2,  senha);
			
			ResultSet rs = pstmt.executeQuery();
			boolean resultado = rs.next();
			System.out.println("Resultado: " + resultado);
			return resultado;
			
		} catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public Usuario obterUsuarioPorLogin(String login) throws SQLException {
        Usuario usuario = null;
        String sql = "SELECT * FROM Usuario WHERE login = ?";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, login);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id");
                    String nome = rs.getString("nome");
                    String cpf = rs.getString("cpf");
                    String telefone = rs.getString("telefone");
                    String endereco = rs.getString("endereco");
                    String email = rs.getString("email");
                    String senha = rs.getString("senha");
                    usuario = new Usuario(id, nome, cpf, telefone, endereco, email, login, senha);
                }
            }
        }
        
        return usuario;
    }
	
	public List<Venda> obterComprasPorUsuario(int usuarioId) throws SQLException {
        List<Venda> compras = new ArrayList<>();
        String sql = "SELECT * FROM Venda WHERE usuario_id = ?";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, usuarioId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Venda venda = new Venda();
                    venda.setId(rs.getInt("id"));
                    venda.setDataHora(rs.getTimestamp("data_hora"));
                    venda.setUsuarioId(rs.getInt("usuario_id"));
                    compras.add(venda);
                }
            }
        }
        return compras;
    }
	
	public List<VendaProduto> obterProdutosPorVenda(int vendaId) throws SQLException {
	    List<VendaProduto> produtos = new ArrayList<>();
	    String sql = "SELECT * FROM Venda_Produto WHERE venda_id = ?";

	    try (Connection conn = Conexao.getConexao();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        pstmt.setInt(1, vendaId);
	        try (ResultSet rs = pstmt.executeQuery()) {
	            while (rs.next()) {
	                VendaProduto produto = new VendaProduto();
	                produto.setVendaId(rs.getInt("venda_id"));
	                produto.setProdutoId(rs.getInt("produto_id"));
	                produto.setQuantidade(rs.getInt("quantidade"));
	                produto.setPreco(rs.getDouble("preco"));
	                produtos.add(produto);
	            }
	        }
	    }
	    return produtos;
	}
}