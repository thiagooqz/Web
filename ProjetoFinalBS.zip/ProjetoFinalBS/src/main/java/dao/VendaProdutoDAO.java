package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexao.Conexao;
import modelo.VendaProduto;

public class VendaProdutoDAO {

    public List<VendaProduto> obterTodosVendaProdutos() {
        List<VendaProduto> vendaProdutos = new ArrayList<>();
        String sql = "SELECT * FROM Venda_Produto";

        try {
            Connection conn = Conexao.getConexao();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int vendaId = rs.getInt("venda_id");
                int produtoId = rs.getInt("produto_id");
                int quantidade = rs.getInt("quantidade");
                double preco = rs.getDouble("preco");

                vendaProdutos.add(new VendaProduto(vendaId, produtoId, quantidade, preco));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vendaProdutos;
    }

    public VendaProduto obterVendaProduto(int vendaId, int produtoId) {
        VendaProduto vendaProduto = null;
        String sql = "SELECT * FROM Venda_Produto WHERE venda_id = ? AND produto_id = ?";

        try {
            Connection conn = Conexao.getConexao();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, vendaId);
            pstmt.setInt(2, produtoId);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int quantidade = rs.getInt("quantidade");
                double preco = rs.getDouble("preco");

                vendaProduto = new VendaProduto(vendaId, produtoId, quantidade, preco);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vendaProduto;
    }

    public boolean inserirVendaProduto(VendaProduto vendaProduto) {
        String sql = "INSERT INTO Venda_Produto (venda_id, produto_id, quantidade, preco) VALUES (?, ?, ?, ?)";

        try {
            Connection conn = Conexao.getConexao();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, vendaProduto.getVendaId());
            pstmt.setInt(2, vendaProduto.getProdutoId());
            pstmt.setInt(3, vendaProduto.getQuantidade());
            pstmt.setDouble(4, vendaProduto.getPreco());

            int tuplasInseridas = pstmt.executeUpdate();
            return tuplasInseridas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarVendaProduto(VendaProduto vendaProduto) {
        String sql = "UPDATE Venda_Produto SET quantidade = ?, preco = ? WHERE venda_id = ? AND produto_id = ?";

        try {
            Connection conn = Conexao.getConexao();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, vendaProduto.getQuantidade());
            pstmt.setDouble(2, vendaProduto.getPreco());
            pstmt.setInt(3, vendaProduto.getVendaId());
            pstmt.setInt(4, vendaProduto.getProdutoId());

            int tuplasAtualizadas = pstmt.executeUpdate();
            return tuplasAtualizadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean removerVendaProduto(int vendaId, int produtoId) {
        String sql = "DELETE FROM Venda_Produto WHERE venda_id = ? AND produto_id = ?";

        try {
            Connection conn = Conexao.getConexao();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, vendaId);
            pstmt.setInt(2, produtoId);

            int tuplasRemovidas = pstmt.executeUpdate();
            return tuplasRemovidas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
