package servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

import dao.UsuarioDAO;
import modelo.Usuario;
import modelo.Venda;
import modelo.VendaProduto;

@WebServlet("/detalhesCompra")
public class DetalhesCompraServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession();
        String login = (String) sessao.getAttribute("loginUsuario");

        if (login == null) {
            response.sendRedirect("login.html");
            return;
        }

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario usuario;
        List<VendaProduto> produtosUsuario = new ArrayList<>();

        try {
            usuario = usuarioDAO.obterUsuarioPorLogin(login);
        } catch (SQLException e) {
            throw new ServletException(e);
        }

        int usuarioId = usuario.getId();
        try {
            List<Venda> compras = usuarioDAO.obterComprasPorUsuario(usuarioId);
            for (Venda compra : compras) {
                List<VendaProduto> produtos = usuarioDAO.obterProdutosPorVenda(compra.getId());
                produtosUsuario.addAll(produtos);
            }
            request.setAttribute("produtosUsuario", produtosUsuario);
            request.getRequestDispatcher("detalhes.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
