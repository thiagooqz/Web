package servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import dao.UsuarioDAO;
import modelo.Usuario;
import modelo.Venda;
import modelo.VendaProduto;

@WebServlet("/baixarRelatorio")
public class RelatorioComprasServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession();
        String login = (String) sessao.getAttribute("loginUsuario");

        if (login == null) {
            response.sendRedirect("login.html");
            return;
        }

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario usuario;
        try {
            usuario = usuarioDAO.obterUsuarioPorLogin(login);
        } catch (SQLException e) {
            throw new ServletException(e);
        }

        int usuarioId = usuario.getId();
        try {
            List<Venda> compras = usuarioDAO.obterComprasPorUsuario(usuarioId);
            response.setContentType("text/plain");
            response.setHeader("Content-Disposition", "attachment; filename=relatorio_compras.txt");
            PrintWriter out = response.getWriter();
            
            out.println("Relatório de Compras");
            
            for (Venda venda : compras) {
                out.println("Compra ID: " + venda.getId());
                out.println("Data e Hora: " + venda.getDataHora());
                
                List<VendaProduto> produtos = usuarioDAO.obterProdutosPorVenda(venda.getId());
                double totalCompra = 0;
                
                for (VendaProduto produto : produtos) {
                	double subtotal = produto.getPreco() * produto.getQuantidade();
                    totalCompra += subtotal;
                    
                    out.println("Produto ID: " + produto.getProdutoId() + ", Quantidade: " + produto.getQuantidade() + ", Preço: " + produto.getPreco() + ", Subtotal: " + subtotal);
                }
                out.println("Total: " + totalCompra);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
