package servlet;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UsuarioDAO;
import modelo.Usuario;

@WebServlet("/deletarUsuario")
public class DeletarUsuarioServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession();
        String login = (String) sessao.getAttribute("loginUsuario");

        if (login == null) {
            response.sendRedirect("login.html");
            return;
        }

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        try {
            Usuario usuario = usuarioDAO.obterUsuarioPorLogin(login);
            boolean deletado = usuarioDAO.removerUsuario(usuario.getId());

            if (deletado) {
                sessao.invalidate();
                response.sendRedirect("login.html");
            } else {
                response.sendRedirect("index_user.html");
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
