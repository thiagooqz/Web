package servlet;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.UsuarioDAO;
import modelo.Usuario;

@WebServlet("/atualizarUsuario")
public class AtualizarUsuarioServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession sessao = request.getSession();
        String loginAtual = (String) sessao.getAttribute("loginUsuario");

        if (loginAtual == null) {
            response.sendRedirect("login.html");
            return;
        }

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        try {
            Usuario usuario = usuarioDAO.obterUsuarioPorLogin(loginAtual);

            if (usuario != null) {
                boolean atualizado = false;

                if (request.getParameter("novoLogin") != null) {
                    String novoLogin = request.getParameter("novoLogin");
                    usuario.setLogin(novoLogin);
                    sessao.setAttribute("loginUsuario", novoLogin); 
                    atualizado = usuarioDAO.atualizarUsuario(usuario);
                } 
                if (request.getParameter("email") != null) {
                    String novoEmail = request.getParameter("email");
                    usuario.setEmail(novoEmail);
                    atualizado = usuarioDAO.atualizarUsuario(usuario);
                } 
                if (request.getParameter("novaSenha") != null) {
                    String novaSenha = request.getParameter("novaSenha");
                    usuario.setSenha(novaSenha);
                    atualizado = usuarioDAO.atualizarUsuario(usuario);
                }

                if (atualizado) {
                    response.sendRedirect("user.html");
                } else {
                    response.sendRedirect("at_user.html");
                }
            } else {
                response.sendRedirect("at_user.html");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("at_user.html");
        }
    }
}