package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UsuarioDAO;
import modelo.Usuario;

@WebServlet("/cadastrarUsuario")
public class CadastroServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  
        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String telefone = request.getParameter("numero");
        String endereco = request.getParameter("endereco");
        String email = request.getParameter("email");
        String login = request.getParameter("username");
        String senha = request.getParameter("password");
   
        Usuario usuario = new Usuario(0, nome, cpf, telefone, endereco, email, login, senha);
        
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        boolean resultado = usuarioDAO.cadastrarUsuario(usuario);
        
        if (resultado) {
            response.sendRedirect("login.html");
        } else {
        	response.sendRedirect("cadastro.html");
        }
    }
}