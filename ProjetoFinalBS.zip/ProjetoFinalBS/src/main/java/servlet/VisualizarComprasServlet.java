package servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import dao.UsuarioDAO;
import modelo.Usuario;
import modelo.Venda;

@WebServlet("/visualizarCompras")
public class VisualizarComprasServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession();
        String login = (String) sessao.getAttribute("loginUsuario");

        if (login == null) {
            response.sendRedirect("login.html");
            return;
        }

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario usuario;
        try {
            usuario = usuarioDAO.obterUsuarioPorLogin(login);
        } catch (SQLException e) {
            throw new ServletException(e);
        }

        int usuarioId = usuario.getId();
        try {
            List<Venda> compras = usuarioDAO.obterComprasPorUsuario(usuarioId);
            request.setAttribute("compras", compras);
            request.getRequestDispatcher("compras.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
