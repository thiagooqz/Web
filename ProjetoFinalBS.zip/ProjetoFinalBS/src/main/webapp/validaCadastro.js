
	const formu = document.getElementById('formulario');
	const campos = document.querySelectorAll('.inputs.required');
	const spans = document.querySelectorAll('.msg-validacao');
	const emailRedex = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
	const cpfRedex = /^[0-9]{3}\.[0-9]{3}\.[0-9]{3}\-[0-9]{2}$/;

	function setError(index){
		campos[index].style.border = '2px solid #e63636';
		spans[index].style.display = 'block';

        const asterisk = campos[index].parentElement.querySelector('.required-asterisk');
        asterisk.style.display = 'inline'; 
	}

	function removeError(index) {
		campos[index].style.border = '2px solid #4caf50'; 
		spans[index].style.display = 'none'; 

        const asterisk = campos[index].parentElement.querySelector('.required-asterisk');
        asterisk.style.display = 'none'; 
	}


	function nameValidate() {

		if (campos[0].value.length < 3) {
			setError(0);
		} else {
			removeError(0); 
		}
	}
	
	function validaCPF() {
        let cpf = campos[1].value.replace(/\D/g, '');

        if (!verificaCPF(cpf)) {
        	setError(1);
        } else {
        	removeError(1);
        }
    }


    function verificaCPF(cpf) {
    	var Soma = 0;
    	var Resto;
    	var strCPF = String(cpf).replace(/[^\d]/g, '');

    	if (strCPF.length !== 11)
    		return false;

    	if ([
    		'00000000000', '11111111111', '22222222222', '33333333333', '44444444444', '55555555555','66666666666', '77777777777', '88888888888', '99999999999'
    		].indexOf(strCPF) !== -1)
    		return false;

    	for (let i = 1; i <= 9; i++) {
    		Soma += parseInt(strCPF.substring(i - 1, i)) * (11 - i);
    	}
    	Resto = (Soma * 10) % 11;
    	if ((Resto == 10) || (Resto == 11)) Resto = 0;
    	if (Resto != parseInt(strCPF.substring(9, 10))) return false;

    	Soma = 0;
    	for (let i = 1; i <= 10; i++) {
    		Soma += parseInt(strCPF.substring(i - 1, i)) * (12 - i);
    	}
    	Resto = (Soma * 10) % 11;
    	if ((Resto == 10) || (Resto == 11)) Resto = 0;
    	if (Resto != parseInt(strCPF.substring(10, 11))) return false;

    	return true;
    }


    function validaEmail(){
    	if(!emailRedex.test(campos[2].value)){
    		setError(2);
    	}
    	else
    	{
    		removeError(2);
    	}
    }

    function validaTel() {
    var telefone = campos[3].value;
    var retorno = false;
    
    
    telefone = telefone.replace(/\D/g, "");
    
    
    var valida = telefone.match(/^(\d{2})?(\d{4,5})(\d{4})$/);
    
    if (valida) {
        var fone = valida[5] + "-" + valida[6];
        
        
        if (valida[4]) {
            retorno = valida[4] + fone;
        }
        
        if (valida[2] && valida[3] || valida[3]) {
            retorno = valida[2] + "(" + valida[3] + ")" + fone;
            
        
            if (valida[4]) {
                retorno = valida[2] + "(" + valida[3] + ")" + valida[4] + fone;
            }
            
            if (!valida[2]) {
                retorno = "(" + valida[3] + ")" + fone;
                
             
                if (valida[4]) {
                    retorno = "(" + valida[3] + ")" + valida[4] + fone;
                }
            }
        }
    }
    
    if (retorno) {
        removeError(3);  
    } else {
        setError(3);  
    }
}


    function validaEnde(){
    	if (campos[4].value.length < 3) {
    		setError(4);
    	} else {
    		removeError(4); 
    	}
    }

    function validaUser() {

    	if (campos[5].value.length < 3) {
    		setError(5);
    	} else {
    		removeError(5); 
    	}
    }

    
    function validaPass() {
    const senha = campos[6].value;
    let erro = false;

    
    if (senha.length < 8) {
        document.getElementById('senha-caracteres').style.color = 'red';
        erro = true;
    } else {
        document.getElementById('senha-caracteres').style.color = 'green';
    }

    
    if (!/[A-Z]/.test(senha)) {
        document.getElementById('senha-maiuscula').style.color = 'red';
        erro = true;
    } else {
        document.getElementById('senha-maiuscula').style.color = 'green';
    }

    
    if (!/[a-z]/.test(senha)) {
        document.getElementById('senha-minuscula').style.color = 'red';
        erro = true;
    } else {
        document.getElementById('senha-minuscula').style.color = 'green';
    }

    
    if (!/[@#!$%]/.test(senha)) {
        document.getElementById('senha-simbolo').style.color = 'red';
        erro = true;
    } else {
        document.getElementById('senha-simbolo').style.color = 'green';
    }

    
    if (!/[0-9]/.test(senha)) {
        document.getElementById('senha-numero').style.color = 'red';
        erro = true;
    } else {
        document.getElementById('senha-numero').style.color = 'green';
    }

    
    if (erro) {
        setError(6); 
    } else {
        removeError(6);  
    }
}

   

    function validaPass2(){
    	if(campos[6].value == campos[7].value && campos[7].value.length >= 8){
    		removeError(7);
    	}
    	else
    	{
    		setError(7);
    	}
    }

    formu.addEventListener('submit', (event) => {
        event.preventDefault(); 
      
        
        nameValidate();
        validaCPF();
        validaEmail();
        validaTel();
        validaEnde();
        validaUser();
        validaPass();
        validaPass2();
      
        
        const hasError = Array.from(spans).some((span) => span.style.display === 'block');
      
        if (!hasError) {
          alert('Formulário enviado com sucesso!');
          formu.submit(); 
        } else {
          alert('Corrija os erros antes de enviar.');
        }
      });

      function enviarCadastro(event) {
        event.preventDefault(); 

        const formData = new FormData(document.getElementById('formulario'));

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/cadastrar-cliente', true); 
       
        xhr.onload = function() {
            if (xhr.status === 200) {  
                const response = JSON.parse(xhr.responseText); 
                if (response.success) {
                    alert('Cadastro realizado com sucesso!');
                } else {
                    alert('Ocorreu um erro no cadastro.');
                }
            } else {
                alert('Erro ao enviar os dados. Tente novamente.');
            }
        };   
        xhr.send(formData);
    }
    document.getElementById('formulario').onsubmit = enviarCadastro;

    
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'sua-senha',
  database: 'nome-do-banco'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Conectado ao banco de dados');
});

app.post('/cadastrar-cliente', (req, res) => {
  const { nome, cpf, email, telefone, endereco, usuario, senha } = req.body;

  if (!nome || !cpf || !email || !telefone || !endereco || !usuario || !senha) {
    return res.status(400).send({ message: 'Todos os campos são obrigatórios.' });
  }

  const query = 'INSERT INTO clientes (nome, cpf, email, telefone, endereco, usuario, senha) VALUES (?, ?, ?, ?, ?, ?, ?)';
  const values = [nome, cpf, email, telefone, endereco, usuario, senha];

  db.query(query, values, (err, result) => {
    if (err) {
      return res.status(500).send({ message: 'Erro ao cadastrar cliente.' });
    }
    res.status(200).send({ message: 'Cadastro realizado com sucesso.' });
  });
});

app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});