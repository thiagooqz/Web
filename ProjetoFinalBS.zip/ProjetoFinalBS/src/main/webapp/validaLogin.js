function submitForm(event) {
    // Impede o envio do formulário para validar os campos primeiro
    event.preventDefault();

    if (validateFields()) {
        document.querySelector("form").submit(); // Envia o formulário após a validação
    }
}


function validateFields(){

const userValid = isUserValid(); 
const passwordValid = isPasswordValid();

const loginButton = document.getElementById('login-button'); 
loginButton.disabled = !(userValid && passwordValid);


const errorMessage = document.getElementById('entrarErro'); 

if (!userValid || !passwordValid) {
  errorMessage.style.display = 'block'; 
  errorMessage.textContent = "Email ou senha inválidos"; 
} else {
  errorMessage.style.display = 'none'; 
}
  }


function isUserValid() {

const user = document.getElementById("user").value;

if (!user) {

return false;
}
return validateUser(user);
}

function isPasswordValid() {

const password = document.getElementById('password').value;

if (!password) {

return false
}
return true;
}

function validateUser(user) {

return /\S+@\S+\.\S+/.test(user);

}


