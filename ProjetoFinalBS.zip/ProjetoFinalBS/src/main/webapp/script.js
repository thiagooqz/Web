function saveCart(cart) {
  localStorage.setItem('cart', JSON.stringify(cart));
}

function getCart() {
  const cart = localStorage.getItem('cart');
  return cart ? JSON.parse(cart) : [];
}

function renderCart() {
  const cartItemsContainer = document.getElementById('cart-items');
  const cart = getCart();

  cartItemsContainer.innerHTML = ''; // Limpar itens existentes

  if (cart.length === 0) {
    cartItemsContainer.innerHTML = '<p>Seu carrinho está vazio.</p>';
    return;
  }

  cart.forEach((item, index) => {
    const itemRow = document.createElement('div');
    itemRow.classList.add('cart-item');
    itemRow.innerHTML = `
      <div class="cart-item-details">
        <img src="${item.img}" alt="${item.name}" width="100px" />
        <span>${item.name}</span>
        <span>R$ ${item.price.toFixed(2)}</span>
      </div>
      <div class="cart-item-quantity">
        <button class="btn btn-sm btn-secondary" onclick="updateQuantity(${index}, -1)">-</button>
        <input type="number" value="${item.quantity}" min="1" id="quantity-${index}" onchange="updateQuantity(${index})" />
        <button class="btn btn-sm btn-secondary" onclick="updateQuantity(${index}, 1)">+</button>
      </div>
      <div class="cart-item-total">
        <span>R$ ${(item.price * item.quantity).toFixed(2)}</span>
        <button class="btn btn-sm btn-danger" onclick="removeItem(${index})">Remover</button>
      </div>
    `;
    cartItemsContainer.appendChild(itemRow);
  });

  updateCartTotal();
}

function updateQuantity(index, change = 0) {
  const cart = getCart();
  const quantityInput = document.getElementById(`quantity-${index}`);
  let newQuantity = parseInt(quantityInput.value) + change;

  if (newQuantity <= 0) return;

  cart[index].quantity = newQuantity;
  saveCart(cart);
  renderCart();
}

function removeItem(index) {
  const cart = getCart();
  cart.splice(index, 1); // Remove o item da posição 'index'
  saveCart(cart);
  renderCart();
}

function updateCartTotal() {
  const cart = getCart();
  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  document.getElementById('cart-total').innerText = total.toFixed(2);
}

function clearCart() {
  localStorage.removeItem('cart');
  renderCart();
  updateCartTotal();
}


function isUserLoggedIn() {
  // Verifica no localStorage se existe a informação do login
  const user = localStorage.getItem('user');
  return user !== null; // Retorna true se o usuário estiver logado
}

// Função para finalizar a compra
function checkout() {
  const cart = getCart();
  if (cart.length === 0) {
    alert("Seu carrinho está vazio. Não é possível finalizar a compra.");
  } else {
    alert("Finalizando a compra!");
  }


}

function addToCart(product) {
  console.log('Produto adicionado:', product); // Verifique no console se o produto está correto
  const cart = getCart();
  const existingProductIndex = cart.findIndex(item => item.name === product.name && item.img === product.img);

  if (existingProductIndex === -1) {
    product.quantity = 1;
    cart.push(product);
  } else {
    cart[existingProductIndex].quantity += 1;
  }

  saveCart(cart);
  alert('Produto adicionado ao carrinho!');
}

document.addEventListener('DOMContentLoaded', () => {
  renderCart();

  document.getElementById('clear-cart').addEventListener('click', clearCart);
  document.getElementById('checkout').addEventListener('click', checkout);
});