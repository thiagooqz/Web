package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import conexao.Conexao;
import modelo.Venda;

public class VendaDAO {
	
	public List<Venda> obterTodasVendas(){
		List<Venda> vendas = new ArrayList<>();
		String sql = "SELECT * FROM Venda";
		
		try {
			Connection conn = Conexao.getConexao();
				
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				Timestamp dataHora = rs.getTimestamp("data_hora");
				int usuarioId = rs.getInt("usuario_id");

				vendas.add(new Venda(id, dataHora, usuarioId));
			}
			
			return vendas;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public Venda obterVendaId(int id) {
        Venda venda = null;
        String sql = "SELECT * FROM Venda WHERE id = ?";

        try {
        	Connection conn = Conexao.getConexao();
     
            PreparedStatement pstmt = conn.prepareStatement(sql);
        	pstmt.setInt(1, id);
        	
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
				Timestamp dataHora = rs.getTimestamp("data_hora");
				int usuarioId = rs.getInt("usuario_id");

				venda = new Venda(id, dataHora, usuarioId);
            }
            
            return venda;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
	
	public boolean inserirVenda(Timestamp dataHora, int usuarioId) {
		String sql = "INSERT INTO Venda (data_hora, usuario_id) VALUES (?, ?)";
		
		try{
			Connection conn = Conexao.getConexao();
				
			PreparedStatement pstmt = conn.prepareStatement(sql);
				pstmt.setTimestamp(1, dataHora);
				pstmt.setInt(2, usuarioId);
	
				int tuplasInseridas = pstmt.executeUpdate();
				
				if(tuplasInseridas > 0) {
					return true;
				} else {
					return false;
				}
				
				
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
	
	public boolean atualizarVenda(int id, Timestamp dataHora, int usuarioId) {
        String sql = "UPDATE Venda SET data_hora = ?, usuario_id = ? WHERE id = ?";

        try {
        	Connection conn = Conexao.getConexao();
            
        	PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setTimestamp(1, dataHora);
            pstmt.setInt(2, usuarioId);
            pstmt.setInt(3, id);

            int tuplasModificadas = pstmt.executeUpdate();
            
            if(tuplasModificadas > 0) {
            	return true;
            } else {
            	return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
	
	public boolean removerVenda(int id) {
		String sql = "DELETE FROM Venda WHERE id = ?";
		
		try {
			Connection conn = Conexao.getConexao();
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, id);
			
			int tuplasRemovidas = pstmt.executeUpdate();
			
			if(tuplasRemovidas > 0) {
				return true;
			} else {
				return false;
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}