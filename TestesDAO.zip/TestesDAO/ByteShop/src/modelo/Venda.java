package modelo;

import java.sql.Timestamp;

public class Venda {
	private int id;
	private Timestamp dataHora;
	private int usuarioId;
	
	public Venda(int id, Timestamp dataHora, int usuarioId) {
		this.id = id;
		this.dataHora = dataHora;
		this.usuarioId = usuarioId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Timestamp getDataHora() {
		return dataHora;
	}

	public void setDataHora(Timestamp dataHora) {
		this.dataHora = dataHora;
	}

	public int getUsuarioId() {
		return usuarioId;
	}

	public void setUsuarioId(int usuarioId) {
		this.usuarioId = usuarioId;
	}

	@Override
	public String toString() {
		return "Venda [id=" + id + ", dataHora=" + dataHora + ", usuarioId=" + usuarioId + "]";
	}
}
