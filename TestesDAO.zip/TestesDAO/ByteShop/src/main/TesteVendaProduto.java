package main;

import dao.VendaProdutoDAO;
import modelo.VendaProduto;
import java.util.List;

public class TesteVendaProduto {
    public static void main(String[] args) {
        VendaProdutoDAO vendaProdutoDAO = new VendaProdutoDAO();
/*
        VendaProduto novaVendaProduto = new VendaProduto(1, 4, 3, 3500);
        boolean inserido = vendaProdutoDAO.inserirVendaProduto(novaVendaProduto);
        System.out.println("Deu certo? " + inserido);
        
        List<VendaProduto> listaVendaProdutos = vendaProdutoDAO.obterTodosVendaProdutos();
        System.out.println("Lista de todas as vendas de produtos:");
        for (VendaProduto vp : listaVendaProdutos) {
            System.out.println("Venda ID: " + vp.getVendaId() +
                    ", Produto ID: " + vp.getProdutoId() +
                    ", Quantidade: " + vp.getQuantidade() +
                    ", Preço: " + vp.getPreco());
        }
       
        
/*        
        VendaProduto vendaProdutoObtido = vendaProdutoDAO.obterVendaProduto(1, 1);
        if (vendaProdutoObtido != null) {
            System.out.println("VendaProduto obtido: Venda ID = " + vendaProdutoObtido.getVendaId() +
                    ", Produto ID = " + vendaProdutoObtido.getProdutoId() +
                    ", Quantidade = " + vendaProdutoObtido.getQuantidade() +
                    ", Preço = " + vendaProdutoObtido.getPreco());
        } else {
            System.out.println("não encontrado.");
        }
        
       
        if (vendaProdutoObtido != null) {
            vendaProdutoObtido.setQuantidade(10);
            vendaProdutoObtido.setPreco(299.99);
            boolean atualizado = vendaProdutoDAO.atualizarVendaProduto(vendaProdutoObtido);
            if(atualizado) {
            	System.out.println("Atualizado!");
            } else {
            	System.out.println("Falha ao atualizar!");
            }
        }

*/
        
        
 vendaProdutoDAO.removerVendaProduto(1, 4);
   		
  
        
    }
}
