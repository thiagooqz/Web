package main;

import java.util.List;

import dao.CategoriaDAO;
import modelo.Categoria;

public class TesteCategoria {
	public static void main(String[] args) {
		
		
		CategoriaDAO categoriaDAO = new CategoriaDAO();
		
		/*
		List<Categoria> categorias = null;
		Categoria categoria = null;
		
		categorias = categoriaDAO.obterTodasCategorias();
		if (categorias.size() > 0)
			System.out.println("\nListando categorias:");
		else
			System.out.println("\nNenhuma categoria encontrada");
		for (Categoria cat : categorias) {
			System.out.println(cat);
		}
		*/
		
		
	
		categoriaDAO.inserirCategoria("Cabos e adaptadores");
		
		
		
		
		/*
		categoria = categoriaDAO.obterCategoriaId(1);
		if (categoria != null)
			System.out.println("\nCategoria encontrada: " + categoria.toString());
		else
			System.out.println("\nNenhuma categoria encontrada com esse ID");
		
		categoriaDAO.atualizarCategoria("Comidas (update)", 2); */
		
	//	categoriaDAO.removerCategoria(6);
		
	/*	categorias = categoriaDAO.obterTodasCategorias();
		if (categorias.size() > 0)
			System.out.println("\nListando categorias:");
		else
			System.out.println("\nNenhuma categoria encontrada");
		for (Categoria cat : categorias) {
			System.out.println(cat);
			
		}*/
	}
}