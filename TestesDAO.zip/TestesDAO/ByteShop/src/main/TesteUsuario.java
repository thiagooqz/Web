package main;

import dao.UsuarioDAO;
import modelo.Usuario;

import java.util.List;

public class TesteUsuario {
    public static void main(String[] args) {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        
        //inserir um novo usuário
        Usuario novoUsuario = new Usuario(0, "Teste", "300.456.789-00", "11999998888",
                "Rua A, 123", "teste@email.com", "teste", "senha123");
        boolean usuarioInserido = usuarioDAO.inserirUsuario(novoUsuario);
        
        if(usuarioInserido) {
        	System.out.println("Usuário inserido!");
        	
        } else {
        	System.out.println("Falha ao inserir usuário");
        }
       
        
     /*
        List<Usuario> usuarios = usuarioDAO.obterTodosUsuarios();
        if(usuarios.size() > 0) {
        	System.out.println("\nListando Usuários:");
        } else {
        	System.out.println("\nNenhum usuário encontrado.");
        }
        
        for (Usuario usuario : usuarios) {
            System.out.println(usuario);
        }
        
        
		
        /*
        //obter um usuário pelo ID
        int idBuscarUsuario = 1;
        
        Usuario usuarioEncontrado = usuarioDAO.obterUsuarioId(idBuscarUsuario);
        if (usuarioEncontrado != null) {
            System.out.println("\nUsuário encontrado: " + usuarioEncontrado);
        } else {
            System.out.println("\nNenhum usuário encontrado com ID " + idBuscarUsuario);
        }
        */
        
        /*
        // atualizar um usuário
        Usuario usuarioAtualizar = usuarioDAO.obterUsuarioId(1);
        if (usuarioAtualizar != null) {
            usuarioAtualizar.setNome("João Silva Atualizado");
            usuarioAtualizar.setTelefone("11988887777");
            boolean usuarioAtualizado = usuarioDAO.atualizarUsuario(usuarioAtualizar);
            
            if(usuarioAtualizado) {
            	System.out.println("Usuário atualizado!");
            } else {
            	System.out.println("Falha ao atualizar usuário!");
            }
        }
        */

        /*
        //remover um usuário
        int idRemoverUsuario = 1;
        boolean usuarioRemovido = usuarioDAO.removerUsuario(idRemoverUsuario);
        
        if(usuarioRemovido) {
        	System.out.println("Usuário removido com sucesso!");
        } else {
        	System.out.println("Falha ao remover usuário!");
        }
        */
    }
}
