package main;

import dao.VendaDAO;
import modelo.Venda;

import java.sql.Timestamp;
import java.util.List;

public class TesteVenda {
    public static void main(String[] args) {
        VendaDAO vendaDAO = new VendaDAO();

        //inserir uma nova venda
        Timestamp dataHora = new Timestamp(System.currentTimeMillis());
        int usuarioId = 5; 
        boolean vendaInserida = vendaDAO.inserirVenda(dataHora, usuarioId);

        if (vendaInserida) {
            System.out.println("Venda inserida com sucesso!");
        } else {
            System.out.println("Falha ao inserir venda.");
        }

        //listar todas as vendas
        List<Venda> vendas = vendaDAO.obterTodasVendas();
        if (vendas.isEmpty()) {
            System.out.println("\nNenhuma venda encontrada.");
        } else {
            System.out.println("\nListando Vendas:");
            for (Venda venda : vendas) {
                System.out.println(venda);
            }
        }


        /*
        //obter uma venda pelo ID
        int idBuscarVenda = 1;
        Venda vendaEncontrada = vendaDAO.obterVendaId(idBuscarVenda);
        
        if (vendaEncontrada != null) {
            System.out.println("\nVenda encontrada: " + vendaEncontrada);
        } else {
            System.out.println("\nNenhuma venda encontrada com ID " + idBuscarVenda);
        }
        */

        /*
        //atualizar uma venda
        int idAtualizarVenda = 1;
        Venda vendaParaAtualizar = vendaDAO.obterVendaId(idAtualizarVenda);
        
        if (vendaParaAtualizar != null) {
            vendaParaAtualizar.setDataHora(new Timestamp(System.currentTimeMillis()));
            vendaParaAtualizar.setUsuarioId(2); 
            boolean vendaAtualizada = vendaDAO.atualizarVenda(vendaParaAtualizar.getId(), vendaParaAtualizar.getDataHora(), vendaParaAtualizar.getUsuarioId());
            
            if (vendaAtualizada) {
                System.out.println("Venda atualizada com sucesso!");
            } else {
                System.out.println("Falha ao atualizar venda.");
            }
        }
        */

        /*
        //remover uma venda
        int idRemoverVenda = 1;
        boolean vendaRemovida = vendaDAO.removerVenda(idRemoverVenda);

        if (vendaRemovida) {
            System.out.println("Venda removida com sucesso!");
        } else {
            System.out.println("Falha ao remover venda.");
        }
        */
    }
}
