package main;

import dao.ProdutoDAO;
import modelo.Produto;
import java.util.List;

public class TesteProduto {
    public static void main(String[] args) {
        ProdutoDAO produtoDAO = new ProdutoDAO();
      
        //inserir um novo produto
        Produto novoProduto = new Produto(0, "SMART TV 50 PHILCO 4K ULTRA HD", 3500.15, "foto.jpg", 2, 5);
        boolean produtoInserido = produtoDAO.inserirProduto(novoProduto);
        if(produtoInserido) {
            System.out.println("Produto inserido!");
        } else {
            System.out.println("Falha ao inserir produto");
        }
        
        
        /*
        //listar todos os produtos
        List<Produto> produtos = produtoDAO.obterTodosProdutos();
        if(produtos.size() > 0) {
            System.out.println("\nListando Produtos:");
        } else {
            System.out.println("\nNenhum produto encontrado.");
        }
        
        for (Produto produto : produtos) {
            System.out.println(produto);
        }
        */
        
        /*
        //obter um produto pelo id
        int idBuscarProduto = 2;
        Produto produtoEncontrado = produtoDAO.obterProdutoId(idBuscarProduto);
        if (produtoEncontrado != null) {
            System.out.println("\nProduto encontrado: " + produtoEncontrado);
        } else {
            System.out.println("\nNenhum produto encontrado com ID " + idBuscarProduto);
        }
        */
        
        /*
        //atualizar um produto
        Produto produtoAtualizar = produtoDAO.obterProdutoId(2); 
        if (produtoAtualizar != null) {
            produtoAtualizar.setDescricao("Produto Atualizado");
            produtoAtualizar.setPreco(89.99);
            boolean atualizado = produtoDAO.atualizarProduto(produtoAtualizar);
            
            if(atualizado) {
                System.out.println("Produto atualizado!");
            } else {
                System.out.println("Falha ao atualizar produto!");
            }
        }
        
        
        
        //remover um produto
        int idRemoverProduto = 16;
        boolean produtoRemovido = produtoDAO.removerProduto(idRemoverProduto);
        if(produtoRemovido) {
        System.out.println("Produto removido com sucesso!");
        } else {
        	System.out.println("Falha ao remover produto!");
        }
        */
    }
}
