/**
 * 
 */
/**
 * @author Ruan
 *
 */
module ByteShop {
	requires java.sql;
}